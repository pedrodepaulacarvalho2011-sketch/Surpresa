const home = document.getElementById('home');
const yesBtn = document.getElementById('yesBtn');
const noBtn = document.getElementById('noBtn');
const noMessage = document.getElementById('noMessage');
const overlay = document.getElementById('overlay');
const cursorHearts = document.getElementById('cursorHearts');
const modal = document.getElementById('modal');
const modalTitle = document.getElementById('modalTitle');
const modalCaption = document.getElementById('modalCaption');
const closeModal = document.getElementById('closeModal');
const toast = document.getElementById('toast');
const heartBtn = document.getElementById('heartBtn');
const finalBtn = document.getElementById('finalBtn');

const phrases = [
  'Tem certeza? 🤨',
  'Nem tenta kkkkk 😂',
  'Essa opção não funciona 😎',
  'Resposta incorreta. Tente novamente. ❤️',
  'O botão tá tímido 🫣'
];

let noAttempts = 0;
let giantHeartTriggered = false;
let heartClicks = 0;

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(showToast.timeout);
  showToast.timeout = setTimeout(() => toast.classList.remove('show'), 1800);
}

function moveNoButtonRandomly() {
  noAttempts += 1;
  const message = phrases[(noAttempts - 1) % phrases.length];
  noMessage.textContent = message;

  const rect = noBtn.getBoundingClientRect();
  const maxX = window.innerWidth - rect.width - 16;
  const maxY = window.innerHeight - rect.height - 16;
  const x = Math.max(8, Math.random() * maxX);
  const y = Math.max(8, Math.random() * maxY);

  noBtn.style.position = 'fixed';
  noBtn.style.left = `${x}px`;
  noBtn.style.top = `${y}px`;
}

function createHeartTrail(event) {
  const heart = document.createElement('span');
  heart.className = 'heart-trail';
  heart.textContent = '💗';
  heart.style.left = `${event.clientX}px`;
  heart.style.top = `${event.clientY}px`;
  const dx = (Math.random() - 0.5) * 70;
  const dy = -70 - Math.random() * 40;
  heart.style.setProperty('--dx', `${dx}px`);
  heart.style.setProperty('--dy', `${dy}px`);
  cursorHearts.appendChild(heart);
  setTimeout(() => heart.remove(), 800);
}

function showScreen(screenId) {
  document.querySelectorAll('.screen').forEach((screen) => screen.classList.remove('active'));
  const targetScreen = document.getElementById(screenId);
  if (targetScreen) {
    targetScreen.classList.add('active');
    targetScreen.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}

function openStory() {
  document.body.classList.add('story-open');
  showScreen('welcome');
}

function showGiantHeart() {
  if (giantHeartTriggered) return;
  const heart = document.createElement('div');
  heart.className = 'giant-heart';
  heart.textContent = '❤️';
  document.body.appendChild(heart);
  setTimeout(() => heart.remove(), 1200);
  giantHeartTriggered = true;
  showToast('Coração gigante chegou!');
}

function openModal(title, caption, imageSrc) {
  modalTitle.textContent = title;
  modalCaption.textContent = caption;
  modalMedia.innerHTML = '';
  if (imageSrc) {
    const img = document.createElement('img');
    img.src = imageSrc;
    img.alt = title;
    img.className = 'modal-image';
    modalMedia.appendChild(img);
    modalMedia.classList.add('single');
  } else {
    modalMedia.classList.remove('single');
  }
  modal.classList.remove('hidden');
}

function openSecretGallery() {
  const imagePool = [
    'images/12.jpeg',
    'images/10.jpeg',
    'images/1.jpeg',
    'images/2.jpeg'
  ];
  const selected = imagePool;

  modalTitle.textContent = 'Momentos secretos';
  modalCaption.textContent = 'Quatro lembranças especiais para você';
  modalMedia.innerHTML = '';
  modalMedia.classList.remove('single');
  selected.forEach((src) => {
    const img = document.createElement('img');
    img.src = src;
    img.alt = 'Foto especial';
    modalMedia.appendChild(img);
  });
  modal.classList.remove('hidden');
}

function closeModalWindow() {
  modal.classList.add('hidden');
}

function launchCelebration() {
  const colors = ['#ff69b4', '#ff1493', '#ffd1dc', '#ffffff'];
  for (let i = 0; i < 45; i += 1) {
    const piece = document.createElement('div');
    piece.className = 'celebration-piece';
    piece.style.left = `${Math.random() * window.innerWidth}px`;
    piece.style.background = colors[Math.floor(Math.random() * colors.length)];
    piece.style.animationDuration = `${1.1 + Math.random() * 0.6}s`;
    piece.textContent = Math.random() > 0.5 ? '💖' : '✨';
    document.body.appendChild(piece);
    setTimeout(() => piece.remove(), 1800);
  }

  for (let i = 0; i < 5; i += 1) {
    const firework = document.createElement('div');
    firework.className = 'firework';
    firework.style.left = `${Math.random() * window.innerWidth}px`;
    firework.style.top = `${Math.random() * window.innerHeight * 0.6}px`;
    firework.style.background = colors[Math.floor(Math.random() * colors.length)];
    firework.style.animationDuration = `${0.9 + Math.random() * 0.5}s`;
    document.body.appendChild(firework);
    setTimeout(() => firework.remove(), 1400);
  }

  showToast('Eu também te amo ❤️');
}

noBtn.addEventListener('mouseenter', moveNoButtonRandomly);
noBtn.addEventListener('click', () => {
  moveNoButtonRandomly();
  showToast('Não dá, amor 😄');
});

yesBtn.addEventListener('click', openStory);

document.addEventListener('click', (event) => {
  const targetButton = event.target.closest('[data-target]');
  if (targetButton) {
    showScreen(targetButton.getAttribute('data-target'));
  }
});

window.addEventListener('mousemove', (event) => {
  createHeartTrail(event);
});

heartBtn.addEventListener('click', () => {
  heartClicks += 1;
  if (heartClicks >= 10) {
    openSecretGallery();
    heartClicks = 0;
    showToast('Três lembranças especiais apareceram 💗');
  } else {
    showGiantHeart();
    showToast(`Mais ${10 - heartClicks} cliques para abrir as lembranças 💗`);
  }
});

const konami = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'b', 'a'];
let konamiIndex = 0;
window.addEventListener('keydown', (event) => {
  if (event.key === konami[konamiIndex]) {
    konamiIndex += 1;
    if (konamiIndex === konami.length) {
      showToast('Mensagem secreta: você é o meu mundo 💖');
      konamiIndex = 0;
    }
  } else {
    konamiIndex = 0;
  }
});

document.querySelectorAll('.polaroid').forEach((item) => {
  item.addEventListener('click', () => {
    const title = item.getAttribute('data-title');
    const caption = item.getAttribute('data-caption');
    const imageSrc = item.getAttribute('data-image');
    openModal(title, caption, imageSrc);
  });
});

closeModal.addEventListener('click', closeModalWindow);
modal.addEventListener('click', (event) => {
  if (event.target === modal) {
    closeModalWindow();
  }
});

finalBtn.addEventListener('click', launchCelebration);

function updateCounter() {
  const startDate = new Date('2025-10-10T00:00:00');
  const now = new Date();
  const diff = now - startDate;

  const years = Math.floor(diff / (1000 * 60 * 60 * 24 * 365.25));
  const months = Math.floor((diff % (1000 * 60 * 60 * 24 * 365.25)) / (1000 * 60 * 60 * 24 * 30.44));
  const days = Math.floor((diff % (1000 * 60 * 60 * 24 * 30.44)) / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
  const minutes = Math.floor((diff / (1000 * 60)) % 60);
  const seconds = Math.floor((diff / 1000) % 60);

  document.getElementById('years').textContent = years;
  document.getElementById('months').textContent = months;
  document.getElementById('days').textContent = days;
  document.getElementById('hours').textContent = hours;
  document.getElementById('minutes').textContent = minutes;
  document.getElementById('seconds').textContent = seconds;
}

setInterval(updateCounter, 1000);
updateCounter();

window.addEventListener('load', () => {
  document.querySelectorAll('.polaroid').forEach((item) => {
    item.style.setProperty('--rotate', `${(Math.random() - 0.5) * 10}deg`);
    item.style.setProperty('--tx', `${(Math.random() - 0.5) * 20}px`);
    item.style.setProperty('--ty', `${(Math.random() - 0.5) * 10}px`);
  });

  const images = [
    'images/1.jpeg',
    'images/2.jpeg',
    'images/3.jpeg',
    'images/4.jpeg',
    'images/6.jpeg',
    'images/7.jpeg',
    'images/8.jpeg',
    'images/10.jpeg',
    'images/11.jpeg',
    'images/12.jpeg',
    'images/13.jpeg',
    'images/14.jpeg',
    'images/15.jpeg',
    'images/17.jpeg',
    'images/18.jpeg',
    'images/20.jpeg',
    'images/21.jpeg',
    'images/22.jpeg'
  ];

  document.querySelectorAll('.image-carousel').forEach((carousel) => {
    const track = document.createElement('div');
    track.className = 'carousel-track';
    
    images.concat(images).forEach((src) => {
      const img = document.createElement('img');
      img.src = src;
      img.className = 'carousel-item';
      img.alt = 'Carrossel';
      track.appendChild(img);
    });

    carousel.appendChild(track);
  });
});
